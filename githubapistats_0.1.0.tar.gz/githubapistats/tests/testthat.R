library(testthat)
library(githubapistats)

test_check("githubapistats")
